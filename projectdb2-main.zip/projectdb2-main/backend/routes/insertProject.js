const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('config');
const auth = require('../middleware/auth');
const connectDB = require('../config/db').connectDB;

// @route api/path/insertProject
// @desc logging in
// @access public
// router.post('/', auth, async (req, res) => {  // temporary remove auth for testing purpose
router.post('/', async (req, res) => {
  //console.log('Request body is- ', req.body);

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    console.log(errors.array());
    return res.status(400).json({ errors: errors.array() });
  }
  console.log('insert project api');
  // see if user exists
  var {
    mcsNumber,
    warehouse,
    projectItem,
    projectClass,
    manager,
    supervisor,
    projectStage,
    projectStatus,
    projectType,
    customerApproval,
    autoFillHVAC,
    autoFillPermits,
    autoFillRefrigeration,
    keyStatus,
    scope,
    mcsNotes,
    projectInitiatedDate,
    siteSurveyDate,
    budgetaryDueDate,
    budgetarySubmittedDate,
    proposalScopeDate,
    draftScheduleDate,
    proposalDueDate,
    proposalSubmittedDate,
    scheduledStartDate,
    scheduledTurnoverDate,
    actualTurnoverDate,
    shouldInvoice,
    actualInvoice,
    projectCost,
    customerNumber,
    highScore,
    lowScore,
    mediumScore,
  } = req.body;

  highScore = highScore || 0;
  lowScore = lowScore || 0;
  mediumScore = mediumScore || 0;

  const insertProject =
    'insert into project (mcsNumber, warehouse, projectItem, projectClass, manager,' +
    ' supervisor, projectStage, projectStatus, projectType, customerApproval, autoFillHVAC, autoFillPermits,' +
    ' autoFillRefrigeration, keyStatus, scope, mcsNotes, projectInitiatedDate, siteSurveyDate, budgetaryDueDate,' +
    ' budgetarySubmittedDate, proposalScopeDate, draftScheduleDate, proposalDueDate, proposalSubmittedDate,' +
    ' scheduledStartDate, scheduledTurnoverDate, actualTurnoverDate, shouldInvoice, actualInvoice, ' +
    ' projectCost, customerNumber) values ';
  //console.log(insertProject);

  // Create new date objects and format them as ISO strings
  const projectInitiatedISO = convertToDate(projectInitiatedDate);
  console.log('Project Initiated Date is- ', projectInitiatedISO);
  const siteSurveyISO = convertToDate(siteSurveyDate);
  console.log('Site Survey Date is- ', siteSurveyISO);
  const budgetaryDueISO = convertToDate(budgetaryDueDate);
  const budgetarySubmittedISO = convertToDate(budgetarySubmittedDate);
  const proposalScopeISO = convertToDate(proposalScopeDate);
  const draftScheduleISO = convertToDate(draftScheduleDate);
  const proposalDueISO = convertToDate(proposalDueDate);
  const proposalSubmittedISO = convertToDate(proposalDueDate);
  const scheduledStartISO = convertToDate(scheduledTurnoverDate);
  const scheduledTurnoverISO = convertToDate(scheduledStartDate);
  const actualTurnoverISO = convertToDate(actualTurnoverDate);

  // begin transaction for inserting project
  connectDB.beginTransaction(function (err) {
    if (err) {
      console.log('transaction error is ', err);
      throw err;
    } else {
      console.log('Beginning transaction');

      // for inserting the manager id into project_managers table
      const getProject_id =
        "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'miller_dev' AND TABLE_NAME = 'project'";

      connectDB.query(getProject_id, (err, result1) => {
        if (err) {
          console.log('error occured');
          connectDB.rollback(function () {
            console.log('error: ', err);
            throw err;
          });
        } else {
          console.log('first query executed');
          console.log('new id for project is-', result1);

          // For inserting the project into the project table
          const insertProject2 =
            'insert into project (mcsNumber, warehouse_id, projectItem_id, projectClass_id, ' +
            ' stage_id, status_id, projectType_id, customerApproval_id, autoFillHVAC, autoFillPermits,' +
            ' autoFillRefrigeration, keyStatus, scope, projectInitiatedDate, siteSurvey, budgetaryDue,' +
            ' budgetarySubmitted, proposalScopeDate, draftScheduleDate, proposalDue, proposalSubmitted,' +
            ' scheduledStartDate, scheduledTurnover, actualTurnover, shouldInvoice, invoiced, ' +
            ' cost, customerNumber, highScore, lowScore, mediumScore) values (' +
            mcsNumber +
            ', ' +
            warehouse.id +
            ', ' +
            projectItem.id +
            ', ' +
            projectClass.id +
            ', ' +
            projectStage.id +
            ', ' +
            projectStatus.id +
            ', ' +
            projectType.id +
            ', ' +
            customerApproval.id +
            ', ' +
            autoFillHVAC.value +
            ', ' +
            autoFillPermits.value +
            ', ' +
            autoFillRefrigeration.value +
            ", '" +
            keyStatus +
            "', '" +
            scope +
            "', " +
            projectInitiatedISO +
            ', ' +
            siteSurveyISO +
            ', ' +
            budgetaryDueISO +
            ', ' +
            budgetarySubmittedISO +
            ', ' +
            proposalScopeISO +
            ', ' +
            draftScheduleISO +
            ', ' +
            proposalDueISO +
            ', ' +
            proposalSubmittedISO +
            ', ' +
            scheduledStartISO +
            ', ' +
            scheduledTurnoverISO +
            ', ' +
            actualTurnoverISO +
            ', ' +
            shouldInvoice +
            ', ' +
            actualInvoice +
            ", '" +
            projectCost +
            "', '" +
            customerNumber +
            "'," +
            highScore +
            ', ' +
            lowScore +
            ', ' +
            mediumScore +
            ' )';

          connectDB.query(insertProject2, (err, result2) => {
            if (err) {
              connectDB.rollback(function () {
                console.log('error: ', err);
                throw err;
              });
            } else {
              console.log(result2);

              console.log('project insert query executed');

              // get the project id of newly inserted project
              const project_id = result2.insertId;

              //const insertProjectManager = 'insert into project_managers values ?' + project_id + ', ' +  ') ';
              const insertProjectManager = 'insert into project_managers set ?';

              const projectMangerData = {
                project_id: project_id,
                id: manager.id,
              };

              connectDB.query(
                insertProjectManager,
                projectMangerData,
                (err, result) => {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                      console.log('error: ', err);
                      return;
                    });
                  } else {
                    console.log('Insert project manager query executed');

                    const insertProjectSupervisor =
                      'insert into project_supervisors set ?';
                    const projectSupervisorData = {
                      project_id: project_id,
                      id: supervisor.id,
                    };

                    connectDB.query(
                      insertProjectSupervisor,
                      projectSupervisorData,
                      (err,
                      (result) => {
                        if (err) {
                          connectDB.rollback(function () {
                            throw err;
                            console.log('error: ', err);
                            return;
                          });
                        } else {
                          console.log(
                            'Insert project supervisor query executed'
                          );

                          // Commit the transaction
                          connectDB.commit((err) => {
                            if (err) {
                              connectDB.rollback(() => {
                                throw err;
                              });
                            }

                            console.log('Transaction committed successfully');
                            connectDB.end();
                          });
                        }

                        res.send('SUCCESS');
                      })
                    );
                  }
                }
              );
            }
          });
        }
      });
    }

    const insertProjectManager = 'insert into project_managers values ';

    var values = [
      mcsNumber,
      warehouse.id,
      projectItem.id,
      projectClass.id,
      manager.id,
      supervisor.id,
      projectStage.id,
      projectStatus.id,
      projectType.id,
      customerApproval.id,
      autoFillHVAC.value,
      autoFillPermits.value,
      autoFillRefrigeration.value,
      keyStatus,
      scope,
      mcsNotes,
      projectInitiatedISO,
      siteSurveyISO,
      budgetaryDueISO,
      budgetarySubmittedISO,
      proposalScopeISO,
      draftScheduleISO,
      proposalDueISO,
      proposalSubmittedISO,
      scheduledStartISO,
      scheduledTurnoverISO,
      actualTurnoverISO,
      shouldInvoice,
      actualInvoice,
      projectCost || null,
      customerNumber || null,
    ];
  });
});

//convert to ISO date
function convertToDate(date) {
  //console.log('Date is - ', date);
  (date === '') | (date === null)
    ? (date = null)
    : (date = `'${new Date(date)
        .toISOString()
        .slice(0, 19)
        .replace('T', ' ')}'`);

  return date;
}

module.exports = router;
