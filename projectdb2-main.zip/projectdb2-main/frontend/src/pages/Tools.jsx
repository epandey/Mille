const Tools = () => {
  return <div className="title"> Tools</div>;
};

export default Tools;
