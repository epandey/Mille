const Users = () => {
  return <div className="title"> Users</div>;
};

export default Users;
