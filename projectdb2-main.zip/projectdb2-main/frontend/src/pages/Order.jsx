const Order = () => {
  return <div className="title"> Order</div>;
};

export default Order;
