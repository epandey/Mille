const Projects = () => {
  return <div className="title"> Projects</div>;
};

export default Projects;
