const Reports = () => {
  return <div className="title"> Reports</div>;
};

export default Reports;
