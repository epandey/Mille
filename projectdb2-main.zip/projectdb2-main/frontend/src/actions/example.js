import axios from 'axios';
import { setAlert } from './alert';
import { GET_EXAMPLE, EXAMPLE_ERROR } from '../actions/types';
import { axiosBaseURL } from '../utils/axios';

//get posts
export const getExample = () => async (dispatch) => {
  try {
    //const res = await axios.post('http://localhost:3000/api/example');
    const res = await axios.post(axiosBaseURL + 'api/example');

    dispatch({
      type: GET_EXAMPLE,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: EXAMPLE_ERROR,
      payload: { msg: err.response.statusText, staus: err.response.status },
    });
  }
};
