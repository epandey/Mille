import React from 'react';
import { useState, Fragment, useEffect } from 'react';
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
} from '@mui/material';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import { makeStyles } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';

import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';

import { getExample } from '../actions/example';
import example from '../reducers/example';

import PropTypes from 'prop-types';

import { connect } from 'react-redux';

//import Select from '@mui/material/Select';
import Select from 'react-select';
import Spinner from './layout/Spinner';

const Example = ({ getExample, example: { example } }) => {
  useEffect(() => {
    getExample();
  }, [getExample]);

  const cardHeaderStyle = {
    background: '#1976d2',
    color: 'white',
    fontSize: '1.1em',
  };

  return (
    <>
      <>Value from the database</>
      {example === null ? (
        <Spinner />
      ) : (
        <TextField
          id="outlined-basic"
          label="Outlined"
          variant="outlined"
          value={example.state}
        />
      )}
    </>
  );
};

Example.propTypes = {
  getExample: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  example: state.example,
});

export default connect(mapStateToProps, { getExample })(Example);
