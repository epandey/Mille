import React from 'react';

const Records = ({ data }) => {
  return (
    <table className="table">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">City</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item) => (
          <tr>
            <td>{item.cityname} </td>
            <td>{item.cityname} </td>
            <td>{item.mcsNumber} </td>
            <td>{item.cityname} </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Records;
