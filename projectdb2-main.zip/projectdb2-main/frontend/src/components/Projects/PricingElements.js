import * as React from "react";
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  MenuItem,
  TableBody,
} from "@mui/material";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const PricingElements = () => {
  const [status, setStatus] = React.useState([]);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setStatus(value);
  };

  function createData(
    pe,
    title,
    description,
    status,
    invoicestatus,
    dsubnames,
    customer,
    submitdate,
    cost,
    sell,
    penotes
  ) {
    return {
        pe,
        title,
        description,
        status,
        invoicestatus,
        dsubnames,
        customer,
        submitdate,
        cost,
        sell,
        penotes
    };
  }

  const rows = [
   
  ];

  const names = ["All", "Review", "Preparing", "Submitted", "Approved", "Rejected", "Complete"];

  return (
    <>
      
      <Card>
        <CardHeader title="Pricing Elements"
          action={
            <>
              <Button variant="contained" style={{ marginLeft: "0.4rem" }}>
                Add Pricing Element
              </Button>
              <Button variant="contained" style={{ marginLeft: "0.4rem" }}>
                Edit Pricing Element
              </Button>
              <Button variant="contained" style={{ marginLeft: "0.4rem" }}>
                Print Pricing Elements
              </Button>
            </>
          }
        ></CardHeader>
        <CardContent>
          <FormControl sx={{ m: 1, width: 300 }}>
            <InputLabel id="demo-multiple-name-label">Status</InputLabel>
            <Select
              labelId="demo-multiple-name-label"
              id="demo-multiple-name"
              multiple
              value={status}
              onChange={handleChange}
              input={<OutlinedInput label="Status" />}
              //   MenuProps={MenuProps}
              fullWidth
            >
              {names.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  //   style={getStyles(name, personName, theme)}
                >
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>PE#</TableCell>
                  <TableCell align="left">Title</TableCell>
                  <TableCell align="left">Description</TableCell>
                  <TableCell align="left">Status</TableCell>
                  <TableCell align="left">Invoice Status</TableCell>
                  <TableCell align="left">Sub Name(s)</TableCell>
                  <TableCell align="left">Customer</TableCell>
                  <TableCell align="left">Submit Date</TableCell>
                  <TableCell align="left">Cost</TableCell>
                  <TableCell align="left">Sell</TableCell>
                  <TableCell align="left">PE Notes</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.pe}
                    </TableCell>
                    <TableCell align="left">{row.title}</TableCell>
                    <TableCell align="left">{row.description}</TableCell>
                    <TableCell align="left">{row.status}</TableCell>
                    <TableCell align="left">{row.invoicestatus}</TableCell>
                    <TableCell align="left">{row.subnames}</TableCell>
                    <TableCell align="left">{row.customer}</TableCell>
                    <TableCell align="left">{row.submitdate}</TableCell>
                    <TableCell align="left">{row.cost}</TableCell>
                    <TableCell align="left">{row.sell}</TableCell>
                    <TableCell align="left">{row.penotes}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </>
  );
};

export default PricingElements;
