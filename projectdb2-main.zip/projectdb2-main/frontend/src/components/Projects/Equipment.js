import * as React from "react";
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  MenuItem,
  TableBody,
} from "@mui/material";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const Equipment = () => {
  const [status, setStatus] = React.useState([]);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setStatus(value);
  };

  function createData(
    name,
    description,
    supplier,
    proposaldate,
    deliverystatus,
    ordereddate,
    scheduleddate,
    actualdate,
    notes,
    unitprice,
    quantity,
    totalprice
  ) {
    return {
    name,
    description,
    supplier,
    proposaldate,
    deliverystatus,
    ordereddate,
    scheduleddate,
    actualdate,
    notes,
    unitprice,
    quantity,
    totalprice
    };
  }

  const rows = [
    createData(
      "Plumbing Parts",
      "Perform annual safety inspections for Con Edison.",
      "Supplier 1",
      "10/08/2021",
      "Delivered",
      "10/20/2021",
      "10/20/2021",
      "10/20/2021",
      "None",
      "$259",
      3,
      "$259"
    ),
    createData(
      "Plumbing Parts",
      "Perform annual safety inspections for Con Edison.",
      "Supplier 2",
      "11/09/2021",
      "Yet to be delivered",
      "11/25/2021",
      "11/25/2021",
      "11/25/2021",
      "None",
      "$459",
      3,
      "$259"
    ),
    
  ];

  

  return (
    <>
      <Card >
        <CardHeader
          style={{ background: "#1976d2", color: "white" }}
          title="Proposals"
        ></CardHeader>
      </Card>

      <Card>
        <CardHeader title="Equipment"
          action={
            <>
              <Button variant="contained" style={{ marginLeft: "0.4rem" }}>
                Add Equipment
              </Button>
              <Button variant="contained" style={{ marginLeft: "0.4rem" }}>
                Edit Equipment
              </Button>
              <Button variant="contained" style={{ marginLeft: "0.4rem", background: "green" }}>
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>
        <CardContent>
          
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell >Name</TableCell>
                  <TableCell align="left">Description</TableCell>
                  <TableCell align="left">Supplier</TableCell>
                  <TableCell align="left">Proposal Date</TableCell>
                  <TableCell align="left">Delivery Status</TableCell>
                  <TableCell align="left">Ordered Date</TableCell>
                  <TableCell align="left">Scheduled Date</TableCell>
                  <TableCell align="left">Actual Date</TableCell>
                  <TableCell align="left">Notes</TableCell>
                  <TableCell align="left">Unit Price</TableCell>
                  <TableCell align="left">Quantity</TableCell>
                  <TableCell align="left">Total Price</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.name}
                    </TableCell>
                    <TableCell align="left">{row.description}</TableCell>
                    <TableCell align="left">{row.supplier}</TableCell>
                    <TableCell align="left">{row.proposaldate}</TableCell>
                    <TableCell align="left">{row.deliverystatus}</TableCell>
                    <TableCell align="left">{row.ordereddate}</TableCell>
                    <TableCell align="left">{row.scheduleddate}</TableCell>
                    <TableCell align="left">{row.actualdate}</TableCell>
                    <TableCell align="left">{row.notes}</TableCell>
                    <TableCell align="left">{row.unitprice}</TableCell>
                    <TableCell align="left">{row.quantity}</TableCell>
                    <TableCell align="left">{row.totalprice}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </>
  );
};

export default Equipment;
