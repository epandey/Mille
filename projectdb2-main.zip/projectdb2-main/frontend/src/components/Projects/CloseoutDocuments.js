import * as React from "react";
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
} from "@mui/material";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const CloseoutDocuments = () => {
  const [category, setCategory] = React.useState();
  return (
    <>
      <Card style={{ marginLeft: "5rem", marginRight: "5rem" }}>
        <CardHeader
          title="Closeout Documents"
          action={
            <>
              <Button
                variant="contained"
                style={{ marginLeft: "0.4rem", background: "green" }}
              >
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>

        <TableContainer component={Paper}>
          <Table
            sx={{ minWidth: 650 }}
            style={{
              borderWidth: "1px",
              borderColor: "#aaaaaa",
              borderStyle: "solid",
            }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow>
                <TableCell style={{ borderBottomColor: "black" }}></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    borderRight: "black",
                    textAlign: "center",
                  }}
                >Closeout Document Status</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Closeout Document Updated</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                ></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >HVAC CO created?</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Refrigeration CO created?</TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Costco Closeout SignOff</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Travel, Rentals, and Freight CO</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Punch List</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >As-Built Drawings</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Closeout Photos</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >HVAC Startup Form</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Shutdown Report</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Alarm Form</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >PBN/MT Screenshot</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
            </TableHead>
          </Table>
          <Table style={{ marginTop: "2rem"}}>
            <TableRow>
                <TableCell style={{ borderBottomColor: "black" }}></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    borderRight: "black",
                    textAlign: "center",
                  }}
                >Salvage Status</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Amount</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Date Updated</TableCell>
            </TableRow>
            <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    borderBottomColor: "black",
                    width: "20%"
                  }}
                >Salvage Value</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    borderBottomColor: "black"
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  /></TableCell>
                  <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    borderBottomColor: "black"
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  /></TableCell>
                  <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                    borderBottomColor: "black"
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    
                    style={{ width:"100%", align: "center" }}
                  />
                </TableCell>
            </TableRow>
          </Table>
          <Table style={{ marginTop: "2rem"}}>
            <TableRow>
                <TableCell style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderTopColor: "black",
                    borderStyle: "solid",
                    width: "20%"
                  }}>Closeout Documents Notes</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderTopColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    style={{ width:"100%", align: "center" }}
                  />
                </TableCell>
            </TableRow>
          </Table>
        </TableContainer>
      </Card>
    </>
  );
};

export default CloseoutDocuments;
