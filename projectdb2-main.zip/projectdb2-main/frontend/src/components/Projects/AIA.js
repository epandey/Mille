import * as React from "react";
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
} from "@mui/material";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const AIA = () => {
  const [category, setCategory] = React.useState();
  return (
    <>
      <Card style={{ marginLeft: "15rem", marginRight: "15rem" }}>
        <CardHeader
          style={{ background: "#1976d2", color: "white" }}
          title="Closeout"
        ></CardHeader>
      </Card>
      <Card style={{ marginLeft: "15rem", marginRight: "15rem" }}>
        <CardHeader
          title="AIA"
          action={
            <>
              <Button
                variant="contained"
                style={{ marginLeft: "0.4rem", background: "green" }}
              >
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>

        <TableContainer component={Paper}>
          <Table
            sx={{ minWidth: 650 }}
            style={{
              borderWidth: "1px",
              borderColor: "#aaaaaa",
              borderStyle: "solid",
            }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow>
                <TableCell style={{ borderBottomColor: "black" }}></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    borderRightColor: "black",
                    textAlign: "center",
                  }}
                >
                  AIA Status
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >
                  AIA Updated
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  G704 - Certificate of Substantial Completion
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  G706 - Affidavit of Payment of Debts and Claims
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>

                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  G706A - Contractor's Lien Releases
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>

                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  MG2 Project Sign-off
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  Equipment Submittal
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  Operations and Maintenance Manuals
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
            </TableHead>
          </Table>
        </TableContainer>
      </Card>
    </>
  );
};

export default AIA;
