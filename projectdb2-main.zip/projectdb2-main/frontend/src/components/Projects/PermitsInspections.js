import * as React from 'react';
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
} from '@mui/material';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';

import { makeStyles } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';

import {
  generalInfoFieldsStyle,
  generalInfoNameStyle,
  selectStyles,
} from './Style';

const cardStyle = {
  marginLeft: '10rem',
  marginRight: '10rem',
};

const PermitsInspections = () => {
  const [category, setCategory] = React.useState();
  return (
    <>
      <Card style={cardStyle}>
        <CardHeader
          title="Permits/Inspections"
          action={
            <>
              <Button
                variant="contained"
                style={{ marginLeft: '0.4rem', background: 'green' }}
              >
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>

        <TableContainer component={Paper}>
          <Table
            sx={{ minWidth: 650 }}
            style={{
              borderWidth: '1px',
              borderColor: '#aaaaaa',
              borderStyle: 'solid',
            }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow>
                <TableCell style={{ borderBottomColor: 'black' }}></TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    borderRight: 'black',
                    textAlign: 'center',
                  }}
                >
                  Permits Required
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    textAlign: 'center',
                  }}
                >
                  Permit Status
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    textAlign: 'center',
                  }}
                >
                  Permit Updated
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    textAlign: 'center',
                  }}
                >
                  Inspection Required
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    textAlign: 'center',
                  }}
                >
                  Inspection Status
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderColor: 'black',
                    textAlign: 'center',
                  }}
                >
                  Inspection Updated
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Building
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Ceiling
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Mechanical
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Electrical
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Plumbing
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Gas
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Sprinkler
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Fire Alarm
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Low Voltage
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Temp Cert Occupancy
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  Cert Occupancy
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={['N/A', 'Incomplete', 'Complete']}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: 'bold',
                    borderWidth: '1px',
                    borderColor: '#aaaaaa',
                    borderRightColor: 'black',
                    borderStyle: 'solid',
                    textAlign: 'center',
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: 'center' }}
                  />
                </TableCell>
              </TableRow>
            </TableHead>
          </Table>
          <Table style={{ marginTop: '2rem' }}>
            <TableRow>
              <TableCell
                style={{
                  fontWeight: 'bold',
                  borderWidth: '1px',
                  borderColor: '#aaaaaa',
                  borderRightColor: 'black',
                  borderStyle: 'solid',
                  borderTopColor: 'black',
                }}
              >
                Building Permit Expiration Date
              </TableCell>
              <TableCell
                style={{
                  fontWeight: 'bold',
                  borderWidth: '1px',
                  borderColor: '#aaaaaa',
                  borderRightColor: 'black',
                  borderStyle: 'solid',
                  textAlign: 'center',
                  borderTopColor: 'black',
                }}
              >
                <TextField
                  id="outlined-basic"
                  label="Enter Text"
                  variant="outlined"
                  size="small"
                  style={{ width: '100%', align: 'center' }}
                />
              </TableCell>
              <TableCell
                style={{
                  fontWeight: 'bold',
                  borderWidth: '1px',
                  borderColor: '#aaaaaa',
                  borderRightColor: 'black',
                  borderStyle: 'solid',
                  borderTopColor: 'black',
                }}
              >
                Permit/Inspection Notes
              </TableCell>
              <TableCell
                style={{
                  fontWeight: 'bold',
                  borderWidth: '1px',
                  borderColor: '#aaaaaa',
                  borderRightColor: 'black',
                  borderStyle: 'solid',
                  textAlign: 'center',
                  borderTopColor: 'black',
                }}
              >
                <TextField
                  id="outlined-basic"
                  label="Enter Text"
                  variant="outlined"
                  size="small"
                  style={{ width: '100%', align: 'center' }}
                />
              </TableCell>
            </TableRow>
          </Table>
        </TableContainer>
      </Card>
    </>
  );
};

export default PermitsInspections;
