import * as React from 'react';
import { useEffect } from 'react';
import { getProjectTasks } from '../../actions/projects';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Moment from 'moment';
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  MenuItem,
  TableBody,
} from '@mui/material';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Spinner from '../layout/Spinner';

const Tasks = ({
  project,
  getProjectTasks,
  projectTasks: { projectTasks },
}) => {
  //const project = projectArguments;
  //alert(project[0].project_id);
  //alert(projectTasks);

  useEffect(() => {
    getProjectTasks(project[0].project_id);
  }, [getProjectTasks]);

  console.log('Project tasks are- ', projectTasks);

  const [status, setStatus] = React.useState([]);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setStatus(value);
  };

  // projectTasks === null
  //   ? console.log('Projects tasks data is-', projectTasks)
  //   : console.log('Projects tasks data is-', projectTasks);

  function createData(
    task,
    description,
    mcs,
    asignee,
    due,
    priority,
    status,
    notes
  ) {
    return {
      task,
      description,
      mcs,
      asignee,
      due,
      priority,
      status,
      notes,
    };
  }

  const rows = [
    createData(
      'Plumbing Repairs/ Gas Inspection',
      'Perform annual safety inspections for Con Edison.',
      'Alex Wagner',
      'Expert Mechanical',
      '10/08/2021',
      '1',
      'Open',
      '-'
    ),
    createData(
      'Plumbing Repairs/ Gas Inspection',
      'Perform annual safety inspections for Con Edison.',
      'Alex Wagner',
      'Expert Mechanical',
      '10/08/2021',
      '1',
      'Open',
      '-'
    ),
    createData(
      'Plumbing Repairs/ Gas Inspection',
      'Perform annual safety inspections for Con Edison.',
      'Alex Wagner',
      'Expert Mechanical',
      '10/08/2021',
      '1',
      'Open',
      '-'
    ),
  ];

  const names = ['All', 'Open & Complete', 'Open', 'Complete', 'Closed'];

  // const ProjectTasksData = (projectTasks) => {
  //   //return <TableCell></TableCell>;
  //   if (projectTasks === null) {
  //     //console.log('if of projecttasksData');
  //     return <TableRow> No data to show</TableRow>;
  //   } else if (projectTasks === 'FAIL') {
  //     return <TableRow> No data to show</TableRow>;
  //   } else {
  //     //console.log('else of projectTasksData');
  //     console.log(projectTasks);
  //     return projectTasks.map((row) => (
  //       <TableRow
  //         key={row.id}
  //         sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
  //       >
  //         <TableCell component="th" scope="row">
  //           {row.title}
  //         </TableCell>
  //         <TableCell align="left">{row.description}</TableCell>
  //         <TableCell align="left">{row.mcs}</TableCell>
  //         <TableCell align="left">{row.asignee}</TableCell>
  //         <TableCell align="left">
  //           {Moment(row.dueDate).format('MM-dd-yyyy')}
  //           {row.dueDate}
  //         </TableCell>
  //         <TableCell align="left">{row.priority}</TableCell>
  //         <TableCell align="left">{row.status}</TableCell>
  //         <TableCell align="left">{row.notes}</TableCell>
  //       </TableRow>
  //     ));
  //   }
  // };

  return (
    <>
      <Card>
        <CardHeader
          style={{ background: '#1976d2', color: 'white' }}
          title="Project Info"
        ></CardHeader>
      </Card>

      <Card>
        <CardHeader
          title="Tasks"
          action={
            <>
              <Button variant="contained" style={{ marginLeft: '0.4rem' }}>
                Add Task
              </Button>
              <Button variant="contained" style={{ marginLeft: '0.4rem' }}>
                Edit Task
              </Button>
              <Button variant="contained" style={{ marginLeft: '0.4rem' }}>
                Print Tasks
              </Button>
            </>
          }
        ></CardHeader>
        <CardContent>
          <FormControl sx={{ m: 1, width: 300 }}>
            <InputLabel id="demo-multiple-name-label">Task</InputLabel>
            <Select
              labelId="demo-multiple-name-label"
              id="demo-multiple-name"
              multiple
              value={status}
              onChange={handleChange}
              input={<OutlinedInput label="Status" />}
              //   MenuProps={MenuProps}
              fullWidth
            >
              {names.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  //   style={getStyles(name, personName, theme)}
                >
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Task</TableCell>
                  <TableCell align="left">Description</TableCell>
                  <TableCell align="left">MCS</TableCell>
                  <TableCell align="left">Asignee</TableCell>
                  <TableCell align="left">Due</TableCell>
                  <TableCell align="left">Priority</TableCell>
                  <TableCell align="left">Status</TableCell>
                  <TableCell align="left">Notes</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {projectTasks === (null || 'FAIL') ? (
                  <TableRow> No Project Tasks to show</TableRow>
                ) : (
                  //   projectTasks.map((row) => (
                  //     <TableRow key={row.name}>
                  //       <TableCell component="th" scope="row">
                  //         {row.title}
                  //       </TableCell>
                  //       <TableCell align="left">{row.description}</TableCell>
                  //       <TableCell align="left">{row.mcs}</TableCell>
                  //       <TableCell align="left">{row.asignee}</TableCell>
                  //       <TableCell align="left">
                  //         {Moment(row.dueDate).format('MM-DD-YYYY')}
                  //       </TableCell>
                  //       <TableCell align="left">{row.severity}</TableCell>
                  //       <TableCell align="left">{row.taskstatus}</TableCell>
                  //       <TableCell align="left">{row.notes}</TableCell>
                  //     </TableRow>
                  //   ))
                  <Spinner />
                )}
                {/* {projectTasks.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.title}
                    </TableCell>
                    <TableCell align="left">{row.description}</TableCell>
                    <TableCell align="left">{row.mcs}</TableCell>
                    <TableCell align="left">{row.asignee}</TableCell>
                    <TableCell align="left">
                      {Moment(row.dueDate).format('MM-dd-yyyy')}
                    </TableCell>
                    <TableCell align="left">{row.priority}</TableCell>
                    <TableCell align="left">{row.status}</TableCell>
                    <TableCell align="left">{row.notes}</TableCell>
                  </TableRow>
                ))} */}
                {/* {rows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.task}
                    </TableCell>
                    <TableCell align="left">{row.description}</TableCell>
                    <TableCell align="left">{row.mcs}</TableCell>
                    <TableCell align="left">{row.asignee}</TableCell>
                    <TableCell align="left">{row.due}</TableCell>
                    <TableCell align="left">{row.priority}</TableCell>
                    <TableCell align="left">{row.status}</TableCell>
                    <TableCell align="left">{row.notes}</TableCell>
                  </TableRow>
                ))} */}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </>
  );
};

Tasks.propTypes = {
  getProjectTasks: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  projectTasks: state.projectTasks,
});

export default connect(mapStateToProps, {
  getProjectTasks,
})(Tasks);
