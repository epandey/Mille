import * as React from "react";
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
} from "@mui/material";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";

const WarrantyLettersandFinalLiens = () => {
  const [category, setCategory] = React.useState();
  return (
    <>
      <Card style={{ marginLeft: "5rem", marginRight: "5rem" }}>
        <CardHeader
          title="Warranty Letters and Final Liens"
          action={
            <>
              <Button
                variant="contained"
                style={{ marginLeft: "0.4rem", background: "green" }}
              >
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>

        <TableContainer component={Paper}>
          <Table
            sx={{ minWidth: 650 }}
            style={{
              borderWidth: "1px",
              borderColor: "#aaaaaa",
              borderStyle: "solid",
            }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow>
                <TableCell style={{ borderBottomColor: "black" }}></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    borderRight: "black",
                    textAlign: "center",
                  }}
                >Warranty Letter Status</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Warranty Letter Updated</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                ></TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Final Lien Status</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderColor: "black",
                    textAlign: "center",
                  }}
                >Final Lien Updated</TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >MCS Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >MCS Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >GC Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >GC Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Mechanical Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Mechanical Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Electrical Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Electrical Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Plumbing Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Plumbing Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Gas Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Gas Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Sprinkler Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Sprinkler Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Polymer Floor Warranty</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Polymer Floor Lien</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Other Warranty (A)</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Other Lien (A)</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >Other Warranty (B)</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid"
                  }}
                >Other Lien (B)</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                  }}
                >
                  <Autocomplete
                    id="combo-box-demo"
                    value={category}
                    onChange={(event, value) => {
                      console.log(value);
                      setCategory(value);
                    }}
                    options={["N/A", "Incomplete", "Complete"]}
                    size="small"
                    renderInput={(params) => (
                      <TextField {...params} label="Status" />
                    )}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: 300, align: "center" }}
                  />
                </TableCell>
              </TableRow>
            </TableHead>
          </Table>
          <Table style={{ marginTop: "2rem"}}>
            <TableRow>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    borderTopColor: "black"
                  }}
                >Warranty Letter Notes</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                    borderTopColor: "black"
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: "100%", align: "center" }}
                  />
                </TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    borderTopColor: "black"
                  }}
                >Final Liens Notes</TableCell>
                <TableCell
                  style={{
                    fontWeight: "bold",
                    borderWidth: "1px",
                    borderColor: "#aaaaaa",
                    borderRightColor: "black",
                    borderStyle: "solid",
                    textAlign: "center",
                    borderTopColor: "black"
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Enter Text"
                    variant="outlined"
                    size="small"
                    style={{ width: "100%", align: "center" }}
                  />
                </TableCell>
            </TableRow>
          </Table>
        </TableContainer>
      </Card>
    </>
  );
};

export default WarrantyLettersandFinalLiens;
