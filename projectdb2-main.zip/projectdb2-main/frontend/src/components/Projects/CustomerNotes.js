import * as React from 'react';
import {
  Grid,
  Card,
  CardHeader,
  Autocomplete,
  Divider,
  List,
  ListItem,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  ListItemText,
  TextField,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  MenuItem,
  TableBody,
} from '@mui/material';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Spinner from '../layout/Spinner';

const CustomerNotes = (projectArguments) => {
  const { project } = projectArguments;
  //alert(project[0].customerNotes);
  const [customerNotes, setCustomerNotes] = React.useState(
    project[0].customerNotes === null ? '' : project[0].customerNotes
  );

  function createData(
    name,
    description,
    supplier,
    proposaldate,
    deliverystatus,
    ordereddate,
    scheduleddate,
    actualdate,
    notes,
    unitprice,
    quantity,
    totalprice
  ) {
    return {
      name,
      description,
      supplier,
      proposaldate,
      deliverystatus,
      ordereddate,
      scheduleddate,
      actualdate,
      notes,
      unitprice,
      quantity,
      totalprice,
    };
  }

  const rows = [
    createData(
      'Plumbing Parts',
      'Perform annual safety inspections for Con Edison.',
      'Supplier 1',
      '10/08/2021',
      'Delivered',
      '10/20/2021',
      '10/20/2021',
      '10/20/2021',
      'None',
      '$259',
      3,
      '$259'
    ),   
    
  ];

  return (
    <>
      <Card>
        <CardHeader
          style={{ background: '#1976d2', color: 'white' }}
          title="Project Info
           "
        ></CardHeader>
      </Card>

      <Card>
        <CardHeader
          title="Equipment"
          action={
            <>
              <Button variant="contained" style={{ marginLeft: '0.4rem' }}>
                Add Equipment
              </Button>
              <Button variant="contained" style={{ marginLeft: '0.4rem' }}>
                Edit Equipment
              </Button>
              <Button
                variant="contained"
                style={{ marginLeft: '0.4rem', background: 'green' }}
              >
                Save Changes
              </Button>
            </>
          }
        ></CardHeader>
        <CardContent>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableBody>
                {rows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ '&:last-child td, &:last-child th': { border: 1 } }}
                  >
                    <TableCell component="th" scope="row">
                      Customer Notes
                    </TableCell>
                    <TableCell align="left">
                      {/* {project[0].customerNotes === null ? (
                        <Spinner />
                      ) : (
                        <TextField
                          id="outlined-basic"
                          label="Enter Text"
                          variant="outlined"
                          size="small"
                          style={{ width: 300, align: 'center' }}
                          value={customerNotes}
                          onChange={(e) => setCustomerNotes(e)}
                        />
                      )} */}
                      <TextField
                        id="outlined-basic"
                        label="Enter Customer Notes"
                        variant="outlined"
                        size="small"
                        multiline
                        rows={5}
                        minRows={4}
                        style={{ resize: 'vertical', width: '100%' }}
                        value={customerNotes}
                        onChange={(e) => setCustomerNotes(e)}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </>
  );
};

export default CustomerNotes;
