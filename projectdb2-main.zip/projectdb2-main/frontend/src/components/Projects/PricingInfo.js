const PricingInfo = () => {
  return <>Temp</>;
};

export default PricingInfo;
