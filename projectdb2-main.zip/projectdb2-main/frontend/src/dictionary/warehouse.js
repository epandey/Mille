const warehouse = {
  foo: 'bar',
  baz: 42,
};
