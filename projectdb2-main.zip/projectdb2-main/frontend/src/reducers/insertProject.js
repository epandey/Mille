import { INSERT_PROJECT, INSERT_PROJECT_ERROR } from '../actions/types';

const initialState = {
  inserted: null,
  loading: true,
  error: {},
};

export default function (state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case INSERT_PROJECT:
      return {
        ...state,
        inserted: true,
        loading: false,
      };
    case INSERT_PROJECT_ERROR:
      return {
        ...state,
        error: payload,
        loading: false,
      };
    default:
      return state;
  }
}
